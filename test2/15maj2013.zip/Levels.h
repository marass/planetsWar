#pragma once
class Levels
{
public:
	static Levels& Get()                                
	{
		static Levels Instance;
		return Instance;
	}
	~Levels(void);

	void refreshPositions();


};

